/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from '@google/genai';

// --- CONFIGURATION ---
// The system prompt defines the chatbot's conversational style.
// You can change this to test different chatbot conditions.
const SYSTEM_PROMPT = `Your role is to respond in a constructive friction style. This means you should remain polite, respectful, and conversational, while gently encouraging the user to reflect more critically on their assumptions, interpretations, and possible next steps.

General requirements:
- Always maintain a polite, calm, and conversational tone.
- Keep responses approximately 2–8 sentences long.
- Do not use emojis.
- Do not mention that you are following instructions or part of a study.

Core conversational behavior:

1. Do not automatically agree.
- Do not immediately align with the user’s framing, opinion, or conclusion.
- Acknowledge the user’s feelings, but do not automatically validate their interpretation of the situation.

2. Clarify before advising.
- Ask one focused follow-up question when the situation is unclear.
- Use questions to understand the user’s goal, uncertainty, or missing context.
- Do not ask too many questions at once.
- Do not ask a question in every response. Alternate between reflection, balanced advice, and occasional focused questions.

3. Reveal assumptions gently.
- If the user makes a strong assumption, point it out in a soft and respectful way.
- Help the user notice what they may be taking for granted.
- For example, if the user assumes bad intention, invite them to consider whether other explanations are possible.
- You may offer alternative interpretations, but do not construct a full defense of another person.
- Do not defend the other person or make excuses for them.

Important constraints:
- Do NOT sound analytical, skeptical, or detached.
- Do NOT behave like a neutral expert; behave like a conversational partner.
- Do NOT follow the same response structure in every reply. Vary the order and style naturally.
Do not ask a question in every response. Alternate between reflection, balanced advice, and occasional focused questions.
Do not keep postponing advice by asking more questions.


Your goal is to help the user reflect more carefully while still feeling respected. The user should experience you as thoughtful, balanced, and gently challenging, rather than merely comforting or automatically agreeable.`;

const MODEL_NAME = 'gemini-3-flash-preview';
// Fallback for local testing if process.env.GEMINI_API_KEY is not set
const FALLBACK_API_KEY = 'xx';

// --- TYPES ---
interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hello. I am here to assist you today. How can I help you with any questions you might have?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Initialize AI client
  // Using process.env.GEMINI_API_KEY which is automatically injected in this environment
  const ai = new GoogleGenAI({ 
    apiKey: process.env.GEMINI_API_KEY || FALLBACK_API_KEY 
  });

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input.trim() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Build conversation history for the API
      // Note: @google/genai generateContent uses 'user' and 'model' roles
      const contents = messages.concat(userMessage).map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }));

      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents,
        config: {
          systemInstruction: SYSTEM_PROMPT,
          temperature: 0.7,
        },
      });

      const botText = response.text || '';
      const assistantMessage: Message = { role: 'assistant', content: botText };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Chat Error:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Error: Unable to connect to assistant. Please check your connection.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleEndConversation = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      messages
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `chatlog_${timestamp}.json`;
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    
    // Cleanup
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 sm:p-8">
      {/* App Container */}
      <div className="w-full max-w-[800px] h-[680px] bg-surface border border-border rounded-lg flex flex-col shadow-[0_4px_12px_rgba(0,0,0,0.05)] overflow-hidden">
        
        {/* Header */}
        <header className="px-6 py-4 border-b border-border flex justify-between items-center bg-surface">
          <h1 className="text-[14px] font-bold text-[#666666] tracking-[0.05em] uppercase">
            User Study: Conversation Interface
          </h1>
          <div className="flex items-center text-[12px] text-[#999999] font-medium">
            <div className="w-2 h-2 bg-status-success rounded-full mr-2" />
            System Active
          </div>
        </header>

        {/* Chat Window */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 bg-chat-bg chat-scroll space-y-5 flex flex-col"
        >
          {messages.length === 0 && (
            <div className="flex-1 flex flex-col items-center justify-center opacity-30">
              <Bot size={40} className="text-[#888]" strokeWidth={1} />
              <p className="mt-4 text-[13px] uppercase tracking-widest font-semibold">Ready for interaction</p>
            </div>
          )}

          <AnimatePresence initial={false}>
            {messages.map((msg, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <span className={`text-[11px] font-bold uppercase tracking-[0.03em] text-label mb-1 ${
                  msg.role === 'user' ? 'text-right' : 'text-left'
                }`}>
                  {msg.role === 'user' ? 'User' : 'Assistant'}
                </span>
                
                <div className={`max-w-[75%] px-4 py-3 text-[15px] leading-[1.5] ${
                  msg.role === 'user' 
                    ? 'bg-user-msg text-user-text rounded-xl rounded-br-sm' 
                    : 'bg-assistant-msg text-assistant-text rounded-xl rounded-bl-sm'
                }`}>
                  {msg.content}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>


        </div>

        {/* Input Area */}
        <footer className="p-5 sm:p-6 border-t border-border bg-surface flex flex-col gap-3">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your message here..."
              className="flex-1 px-4 py-3 border border-input-border rounded-md text-[15px] outline-none focus:border-input-focus transition-colors"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className={`px-6 py-2 rounded-md font-bold text-[14px] transition-all ${
                !input.trim() || isLoading
                  ? 'bg-assistant-msg text-[#ADB5BD] cursor-not-allowed'
                  : 'bg-btn text-white hover:bg-btn-hover active:scale-[0.98]'
              }`}
            >
              {isLoading ? 'Sending...' : 'Send'}
            </button>
          </div>
          <div className="flex justify-end">
            <button
              onClick={handleEndConversation}
              className="px-4 py-2 border border-border text-[#666] text-[12px] font-bold uppercase tracking-wider rounded-md hover:bg-gray-50 transition-colors"
            >
              End Conversation
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}
